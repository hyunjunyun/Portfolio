
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Ct {

	private Socket cs;

	private DataInputStream in;

	private DataOutputStream out;

	private Cgui cgui;

	private String msg;

	private String nickName;

	public final void setCgui(Cgui cgui) {

		this.cgui = cgui;

	}
	
	//서버의 포트와 연결
	public void connect() {

		try {

			cs = new Socket("127.0.0.1", 7777);

			in = new DataInputStream(cs.getInputStream());

			out = new DataOutputStream(cs.getOutputStream());

			out.writeUTF(nickName);

			while (in != null) {
				msg = in.readUTF();
				cgui.appendMsg(msg);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	
	//서버에 메시지를 보내서 서버에서 다시 클라이언트들에 뿌려준다
	public void sendMessage(String msg2) {
		try {
			out.writeUTF(msg2);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	
	//닉네임 설정
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

}