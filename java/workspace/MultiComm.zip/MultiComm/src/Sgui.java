import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

//서버는 사실 상 로그를 띄우는 부분
public class Sgui extends JFrame implements ActionListener { 

	private JTextField jtf;

	JTextArea jta;

	private Sv sv = new Sv();

	
	//UI 세팅
	public Sgui() throws IOException {
		
		setTitle("Server");

		setSize(300, 500);
		setLocationRelativeTo(null);
		
		jtf = new JTextField(25);
		jta = new JTextArea();
		
		JScrollPane jsc = new JScrollPane(jta);
		
		add(jsc, BorderLayout.CENTER);

		add(jtf, BorderLayout.SOUTH);

		setDefaultCloseOperation(EXIT_ON_CLOSE);

		setVisible(true);

		jtf.addActionListener(this);
		jta.setEditable(false);

		sv.setSg(this);
		sv.setting();
	}

	public static void main(String[] args) throws IOException {
		new Sgui();
	}

	@Override
	//서버 관리자 개입 시 채팅 사용가능
	public void actionPerformed(ActionEvent e) {

		String msg = "server : " + jtf.getText() + "\n";

		sv.sendMessage(msg);
		appendMsg(msg);
		jtf.setText("");
		jta.repaint();
		jta.revalidate();

	}
	
	
	public void appendMsg(String msg) {
		jta.append(msg);
		jta.setCaretPosition(jta.getDocument().getLength());
	}

}