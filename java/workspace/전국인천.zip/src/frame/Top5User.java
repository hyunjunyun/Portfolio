package frame;

public class Top5User extends BaseFrame{

	public Top5User() {
		super(1, 1, "", 2);
	}

}
